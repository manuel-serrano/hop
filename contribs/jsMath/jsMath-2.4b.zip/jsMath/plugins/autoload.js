/*
 *  autoload.js
 *  
 *  Part of the jsMath package for mathematics on the web.
 *
 *  This file is a plugin that checks if a page contains any math
 *  that must be processed by jsMath, and only loads jsMath.js
 *  when there is.
 *  
 *  You can control the items to look for via the variables
 *  
 *      jsMath.Autoload.findMathElements
 *      jsMath.Autoload.findTeXstrings
 *      jsMath.Autoload.findLaTeXstrings
 *  
 *  which control whether to look for SPAN and DIV elements of class
 *  "math", TeX strings that will be converted by jsMath.ConvertTeX(), or
 *  LaTeX strings that will be converted by jsMath.ConvertLaTeX().  By
 *  default, the first is true and the last two are false.
 *  
 *  If any math strings are found, jsMath.js will be loaded automatically, 
 *  but not loaded otherwise.  If any of the last two are true and TeX math
 *  strings are found, then plugins/tex2ath.js will be loaded
 *  automatically.  jsMath.Autoload.needsJsMath will be set to true or
 *  false depending on whether jsMath needs to be loaded.
 *  
 *  The value of jsMath.Autoload.element controls the element to be
 *  searched by the autoload plug-in.  If unset, the complete document will
 *  be searched.  If set to a string, the element with that name will be
 *  searched.  If set to a DOM object, that object and its children will
 *  be searched.
 *  
 *  Finally, there are two additional parameters that control files to
 *  be loaded after jsMath.js, should it be needed.  These are
 *  
 *      jsMath.Autoload.loadFonts
 *      jsMath.Autoload.loadFiles
 *  
 *  If jsMath.js is loaded, the fonts contained in the loadFonts array
 *  will be loaded, and the JavaScript files listed in the loadFiles array
 *  will be run.  Relative URL's are loaded based from the URL containing
 *  jsMath.js.
 *  
 *  ---------------------------------------------------------------------
 *
 *  jsMath is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  jsMath is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with jsMath; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*************************************************************************/

/*
 *  Make sure jsMath.Autoload is available
 */
if (jsMath == null) {var jsMath = {}}
if (jsMath.Autoload == null) {jsMath.Autoload = {}}

/*
 *  Look to see if there are SPAN or DIV elements of class "math".
 */
jsMath.Autoload.areMathElements = function (obj) {
  if (!obj) {obj = document}
  if (typeof(obj) == 'string') {obj = document.getElementById(obj)}
  if (!obj.getElementsByTagName) {return false}
  var math = obj.getElementsByTagName('DIV');
  for (var k = 0; k < math.length; k++) 
    {if (math[k].className == 'math') {return true}}
  math = obj.getElementsByTagName('SPAN');
  for (var k = 0; k < math.length; k++) 
    {if (math[k].className == 'math') {return true}}
  return false;
};

/*
 *  The patterns used for searching for TeX and LaTeX math strings
 *  (taken from plugins/tex2math.js).
 */
jsMath.Autoload.pattern = {
  tex:   /((^|[^\\])(\\[^\[\(])*)(\\\((([^\\]|\\[^\)])*)\\\)|\\\[(([^\\]|\\[^\]])*)\\\]|(\$\$?)(([^$\\]|\\.)*)\9)/,
  latex: /((^|[^\\])(\\[^\[\(])*)(\\\((([^\\]|\\[^\)])*)\\\)|\\\[(([^\\]|\\[^\]])*)\\\])/
};

/*
 *  Recursively search for text elements, and check them for
 *  TeX or LaTeX strings that would be recognized by tex2math.
 */
jsMath.Autoload.FindPattern = function (method,element,recurse) {
  if (!element) {
    if (recurse) {return false};
    element = document.body;
  }
  if (typeof(element) == 'string') {element = document.getElementById(element)}
      
  var pattern = jsMath.Autoload.pattern[method];
  while (element) {
    if (element.nodeName == '#text') {
      if (pattern.exec(element.nodeValue.replace(/\n/g,' '))) {return true}
    } else if (!element.tagName ||
               !element.tagName.match(/^(SCRIPT|NOSCRIPT|STYLE|TEXTAREA|PRE)$/i)) {
      if (this.FindPattern(method,element.firstChild,1)) {return true};
    }
    element = element.nextSibling;
  }
  return false;
};

jsMath.Autoload.areTeXstrings = function (obj) {return this.FindPattern('tex',obj,0)}
jsMath.Autoload.areLaTeXstrings = function (obj) {return this.FindPattern('latex',obj,0)}

/*
 *  When math tags are found, load the jsMath.js file.  If we looked
 *  for TeX and LaTeX strings, load the tex2math as well.
 */
jsMath.Autoload.LoadJsMath = function () {
  if (!jsMath.Autoload.root) {
    var script = document.getElementsByTagName('SCRIPT');
    if (script) {
      for (var i = 0; i < script.length; i++) {
        var src = script[i].src;
        if (src && src.match('(^|/)plugins/autoload.js$')) {
          jsMath.Autoload.root = src.replace(/plugins\/autoload.js$/,'');
          break;
        }
      }
    }
  }
  if (jsMath.Autoload.root) {
    document.write('<SCRIPT SRC="'+jsMath.Autoload.root+'jsMath.js"></'+'SCRIPT>');
    if (jsMath.Autoload.findTeXstrings || jsMath.Autoload.findLaTeXstrings)
      {document.write('<SCRIPT SRC="'+jsMath.Autoload.root+'plugins/tex2math.js"></'+'SCRIPT>')}
  } else {
    alert("Can't determine URL for jsMath.js");
  }
}

/*
 *  Load any specified fonts
 */
jsMath.Autoload.LoadExtraFonts = function () {
  var fonts = jsMath.Autoload.loadFonts;
  if (typeof(fonts) != 'object') {fonts = [fonts]}
  for (var i in fonts) {
    document.writeln('<SCRIPT>jsMath.Font.Load("'+fonts[i]+'")</'+'SCRIPT>');
  }
}

/*
 *  Load any specified files
 */
jsMath.Autoload.LoadExtraFiles = function () {
  var files = jsMath.Autoload.loadFiles;
  if (typeof(files) != 'object') {files = [files]}
  for (var i in files) {
    document.writeln('<SCRIPT>jsMath.Setup.Script("'+files[i]+'")<'+'/SCRIPT>');
  }
}

/*
 *  The default settings
 */
if (jsMath.Autoload.findMathElements == null) {jsMath.Autoload.findMathElements = 1}
if (jsMath.Autoload.findTeXstrings == null)   {jsMath.Autoload.findTeXstrings = 0}
if (jsMath.Autoload.findLaTeXstrings == null) {jsMath.Autoload.findLaTeXstrings = 0}

/*
 *  Look for the requested math strings (stop after the first is found)
 */
jsMath.Autoload.needsJsMath = 0;
if (jsMath.Autoload.findMathElements) {
  jsMath.Autoload.needsJsMath = 
    jsMath.Autoload.areMathElements(jsMath.Autoload.checkElement);
}
if (jsMath.Autoload.findTeXstrings && !jsMath.Autoload.needsJsMath) {
  jsMath.Autoload.needsJsMath =
    jsMath.Autoload.areTeXstrings(jsMath.Autoload.checkElement);
}
if (jsMath.Autoload.findLaTeXstrings && !jsMath.Autoload.needsJsMath) {
  jsMath.Autoload.needsJsMath =
    jsMath.Autoload.areLaTeXstrings(jsMath.Autoload.checkElement);
}

/*
 *  If math was found, load jsMath.js and tex2math.js (if needed).
 *  Otherwise, define the routines that are normally called
 *  to process the page, so the author doesn't have to do a
 *  check before calling these.
 */
if (jsMath.Autoload.needsJsMath) {
  jsMath.Autoload.LoadJsMath();
  jsMath.Autoload.LoadExtraFonts();
  jsMath.Autoload.LoadExtraFiles();
} else {
  jsMath.Process = function () {};
  jsMath.ProcessBeforeShowing = function () {};
  jsMath.ConvertTeX = function () {};
  jsMath.ConvertLaTeX = function () {};
}
